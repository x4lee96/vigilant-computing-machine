// requires jQuery
var data = {};
$.ajax('https://census.soe.com/get/ps2:v2/zone?c:limit=100&c:tree=start:regions^list:1&c:join=map_region^list:1^inject_at:regions^hide:zone_id', {
	dataType: 'jsonp',
	success: function(result){
		console.log(result);
		var zones = result.zone_list;

		for(var i = 0; i < zones.length; i++){
			var zone = zones[i];
			if(+zone.zone_id < 50){
				data[+zone.zone_id] = {
					zone_name: zone.code,
					region_types: {}
				}

				var region_types = data[+zone.zone_id].region_types;
				for(var j = 0; j < zone.regions.length; j++){
					var region = zone.regions[j];
					if(!region_types[+region.facility_type_id])
						region_types[+region.facility_type_id] = [];

					region_types[+region.facility_type_id].push({
						1: +region.facility_type_id,
						2: region.facility_id,
						3: region.map_region_id,
						4: region.facility_name
					});
				}
			}
		}
	}
});
 
// export with JSON.stringify(data), indexes are the same as the markdown columns
// use a prettifier for formatting (http://jsonprettyprint.com/)